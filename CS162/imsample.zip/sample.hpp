#ifndef SAMPLE_HPP
#define SAMPLE_HPP

class Sample
{
	public:
		Sample(const char * const str);
};

#endif // SAMPLE_HPP
