#include "sample.hpp"

int main(void)
{
	Sample sample("test");

	return 0;
}
