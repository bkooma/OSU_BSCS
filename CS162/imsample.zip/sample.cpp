#include "sample.hpp"

#include <iostream>

using std::cout;
using std::endl;

Sample::Sample(const char * const str)
{
	cout << "Made Sample w/ " << str << endl;
}
