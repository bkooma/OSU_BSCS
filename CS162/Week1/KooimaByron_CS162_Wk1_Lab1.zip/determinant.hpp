/*************************************************************************************
** determinant.hpp is the determinant class specification file.
** Author:  Byron Kooima
** Date: 2017/06/30
** Description: CS162 Week1 Lab1
***************************************************************************************/

#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

class determinant
{

public:
	// Method for returning the determinant
	int getDeterminant(int **, int);
};

#endif // !READMATRIX_HPP

