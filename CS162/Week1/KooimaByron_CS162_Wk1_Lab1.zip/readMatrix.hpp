/*************************************************************************************
** readMatrix.hpp is the readMatrix class specification file.
** Author:  Byron Kooima
** Date: 2017/06/30
** Description: CS162 Week1 Lab1
***************************************************************************************/

#ifndef READMATRIX_HPP
#define READMATRIX_HPP
#include <iostream>

class readMatrix
{

public:
	// Method for printing the board
	void getMatrix(int **, int);
};

#endif // !READMATRIX_HPP

